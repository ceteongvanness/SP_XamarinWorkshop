using UIKit;

namespace Tasky 
{
	public class Application 
    {
		static void Main (string[] args)
		{
			UIApplication.Main (args, null, "AppDelegate");
		}
	}
}
